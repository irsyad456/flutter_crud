import 'package:crud/homepage.dart';
import 'package:get/get.dart';

class Routes {
  final routes = [
    GetPage(name: '/', page: () => HomePage())
  ];
}